const data = {
    username: "ahmed",
    email: "ahmed@gmail;com",
    birth: "2021-09-09",
    bio: "I am a student"}


const usernameInput = document.querySelector("input[name = 'userName']")
const emailInput = document.querySelector("input[name = 'email']")
const birthInput = document.querySelector("input[name = 'date']")
const bioInput = document.querySelector("textarea[name = 'Bio']")
const editButton = document.querySelector("button[name ='submit']")
const backButton = document.querySelector("#backBt")
const addphotoButton = document.querySelector("#AddImageBt")

usernameInput.placeholder = data.username
emailInput.placeholder = data.email
birthInput.placeholder = data.birth
bioInput.placeholder = data.bio





editButton.addEventListener('click', async (e) => { 
    e.preventDefault()
usernameInput.value = data.username
emailInput.value = data.email
birthInput.value = data.birth
bioInput.value = data.bio

editButton.textContent = "SAVE"
// backButton.style.opacity = 0
backButton.classList.add("hidden")
addphotoButton.classList.add("active")

} )