// const loginButton = document.querySelector("#submit")
const loginButton = document.querySelector("input[name ='submit']")

loginButton.addEventListener('click', async (e) => {
    e.preventDefault()


    location.assign("/EditProfile")


} )